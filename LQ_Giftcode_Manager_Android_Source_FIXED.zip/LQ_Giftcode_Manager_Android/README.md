# LQ Giftcode Manager Android

Ứng dụng Android native Kotlin, chế độ Assist. Cơ sở dữ liệu SQLite cũ được đóng gói trong `app/src/main/assets/history.sqlite3`.

## Chức năng
- Tìm kiếm giftcode theo chuỗi.
- Lọc trạng thái và xem tối đa 1.000 kết quả mỗi lần.
- Sao chép mã đã chọn.
- Mở trang đổi thưởng chính thức `https://giftcode.lienquan.garena.vn/` để người dùng tự thao tác.
- Cập nhật trạng thái thủ công.
- Lưu dữ liệu cục bộ trên điện thoại.

Ứng dụng không đăng nhập Garena, không tự gửi giftcode và không tự động hóa việc nhập mã hàng loạt.

## Dữ liệu
- Nguồn: `history.sqlite3` trích từ gói người dùng tải lên.
- Bảng `history`: 57.591 bản ghi; trạng thái ban đầu được giữ nguyên.

## Tạo APK trực tuyến bằng điện thoại (GitHub Actions)
1. Tải file ZIP dự án này về điện thoại và giải nén.
2. Tạo repository mới trên GitHub (để Private nếu muốn giữ riêng dữ liệu).
3. Trên GitHub, vào repository > Add file > Upload files.
4. Tải **toàn bộ nội dung bên trong thư mục `LQ_Giftcode_Manager_Android`** lên repository, bao gồm cả thư mục ẩn `.github`.
5. Chọn Commit changes.
6. Mở tab **Actions** > workflow **Build LQ Giftcode Manager APK** > **Run workflow**.
7. Chờ workflow chạy xong màu xanh. Mở lần chạy đó, kéo xuống **Artifacts**, tải `LQ-Giftcode-Manager-APK`.
8. Giải nén artifact và cài `app-debug.apk` trên Android. Nếu máy hỏi, cho phép cài ứng dụng từ nguồn này.

Workflow dùng JDK 17 và Gradle 8.9 trên GitHub-hosted runner; không cần cài Android Studio trên điện thoại.
