# LQ Giftcode Manager Android

Ứng dụng Android native Kotlin, chế độ Assist. Cơ sở dữ liệu SQLite cũ được đóng gói nguyên trạng trong `app/src/main/assets/history.sqlite3`.

## Chức năng
- Tìm kiếm giftcode theo chuỗi.
- Lọc trạng thái và xem tối đa 1.000 kết quả mỗi lần.
- Sao chép mã đã chọn.
- Mở trang đổi thưởng chính thức `https://giftcode.lienquan.garena.vn/` để người dùng tự thao tác.
- Cập nhật trạng thái thủ công: `invalid`, `valid`, `used`, `review`.
- Sao chép cơ sở dữ liệu vào vùng lưu trữ riêng của ứng dụng ở lần chạy đầu.

Ứng dụng không đăng nhập Garena, không tự gửi giftcode, không tự động hóa việc nhập mã hàng loạt.

## Dữ liệu
- Nguồn: `history.sqlite3` trích từ gói người dùng tải lên.
- Bảng `history`: 57.591 bản ghi; các cột `id`, `code`, `status`, `created`.
- Trạng thái lịch sử ban đầu được giữ nguyên.

## Biên dịch APK
Cần Android Studio (Hedgehog trở lên), JDK 17/21 và Android SDK Platform 35.
1. Mở thư mục dự án bằng Android Studio.
2. Chờ Gradle Sync hoàn tất.
3. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug thường nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

Dự án được cung cấp dưới dạng mã nguồn; APK chưa được biên dịch trong môi trường tạo tệp hiện tại vì môi trường không có Android SDK/Gradle.
