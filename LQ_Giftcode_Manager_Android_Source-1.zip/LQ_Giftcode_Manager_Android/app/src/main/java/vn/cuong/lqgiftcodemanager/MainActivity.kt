package vn.cuong.lqgiftcodemanager

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.*
import android.view.ViewGroup
import android.view.Gravity
import android.graphics.Color

private const val REDEEM_URL = "https://giftcode.lienquan.garena.vn/"

class GiftDb(context: Context) : SQLiteOpenHelper(context, "giftcodes.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) = Unit
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun initializeFromAsset(context: Context) {
        val target = context.getDatabasePath("giftcodes.db")
        if (target.exists()) return
        target.parentFile?.mkdirs()
        context.assets.open("history.sqlite3").use { input -> target.outputStream().use { input.copyTo(it) } }
    }

    fun search(query: String, status: String): List<Gift> {
        val db = readableDatabase
        val where = mutableListOf<String>()
        val args = mutableListOf<String>()
        if (query.isNotBlank()) { where += "code LIKE ?"; args += "%${query.trim()}%" }
        if (status != "Tất cả") { where += "status = ?"; args += status }
        val sql = "SELECT id, code, status, created FROM history" + if (where.isEmpty()) "" else " WHERE " + where.joinToString(" AND ") + " ORDER BY id DESC LIMIT 1000"
        val result = mutableListOf<Gift>()
        db.rawQuery(sql, args.toTypedArray()).use { c ->
            while (c.moveToNext()) result += Gift(c.getLong(0), c.getString(1), c.getString(2), c.getString(3))
        }
        return result
    }

    fun updateStatus(id: Long, status: String) {
        writableDatabase.update("history", ContentValues().apply { put("status", status) }, "id=?", arrayOf(id.toString()))
    }
    fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM history", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
}

data class Gift(val id: Long, val code: String, val status: String, val created: String) {
    override fun toString() = "$code\nTrạng thái: $status  •  $created"
}

class MainActivity : Activity() {
    private lateinit var db: GiftDb
    private lateinit var query: EditText
    private lateinit var filter: Spinner
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<Gift>
    private var items = listOf<Gift>()
    private var selected: Gift? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = GiftDb(this)
        try { db.initializeFromAsset(this) } catch (e: Exception) {
            Toast.makeText(this, "Không thể khởi tạo dữ liệu: ${e.message}", Toast.LENGTH_LONG).show(); finish(); return
        }
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 16); setBackgroundColor(Color.rgb(247,248,250)) }
        val title = TextView(this).apply { text = "LQ Giftcode Manager"; textSize = 23f; setTextColor(Color.rgb(20,35,55)); typeface = Typeface.DEFAULT_BOLD }
        root.addView(title)
        root.addView(TextView(this).apply { text = "Assist • Dữ liệu lưu trên thiết bị"; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0,4,0,12) })
        root.addView(TextView(this).apply { text = "Tìm kiếm giftcode"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD })
        query = EditText(this).apply { hint = "Nhập mã hoặc một phần mã…"; singleLine = true }
        root.addView(query, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        filter = Spinner(this)
        filter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Tất cả", "invalid", "valid", "used", "review"))
        root.addView(filter)
        val searchBtn = Button(this).apply { text = "Tìm mã"; setOnClickListener { refresh() } }
        root.addView(searchBtn)
        root.addView(TextView(this).apply { text = "Chọn một mã trong danh sách để thao tác:"; textSize = 14f; setPadding(0,10,0,4) })
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, position, _ -> selected = items.getOrNull(position); selected?.let { showSelected(it) } }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "Sao chép mã đã chọn"; setOnClickListener { copySelected() } })
        root.addView(Button(this).apply { text = "Mở trang đổi thưởng Garena"; setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(REDEEM_URL))) } })
        root.addView(TextView(this).apply { text = "Ứng dụng không tự gửi mã. Thầy tự nhập và xác nhận trên trang Garena."; textSize = 12f; setTextColor(Color.DKGRAY); setPadding(0,8,0,0) })
        setContentView(root)
    }

    private fun refresh() {
        items = db.search(query.text?.toString() ?: "", filter.selectedItem?.toString() ?: "Tất cả")
        adapter.clear(); adapter.addAll(items); adapter.notifyDataSetChanged()
        title = "LQ Giftcode Manager (${db.count()} mã)"
        selected = null
    }

    private fun showSelected(g: Gift) {
        AlertDialog.Builder(this).setTitle(g.code).setMessage("Trạng thái hiện tại: ${g.status}\nNgày lưu: ${g.created}\n\nChọn thao tác tiếp theo.")
            .setPositiveButton("Sao chép") { _, _ -> copy(g.code) }
            .setNeutralButton("Đổi trạng thái") { _, _ ->
                val statuses = arrayOf("invalid", "valid", "used", "review")
                AlertDialog.Builder(this).setTitle("Cập nhật trạng thái").setItems(statuses) { _, which -> db.updateStatus(g.id, statuses[which]); refresh() }.show()
            }
            .setNegativeButton("Đóng", null).show()
    }

    private fun copySelected() { val g = selected; if (g == null) Toast.makeText(this, "Thầy hãy chọn một mã trước", Toast.LENGTH_SHORT).show() else copy(g.code) }
    private fun copy(value: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Giftcode", value))
        Toast.makeText(this, "Đã sao chép mã", Toast.LENGTH_SHORT).show()
    }
}
